# extra

Any extra documents you might have go here. This might include Rmd files you're using to develop your project, any notes, or anything else. The contents of this folder will **not** be marked, it's just a convenient place to store documents and collaborate with teammates without cluttering the rest of your repo.
